package edu.rose.snack.snackplus.models

import android.os.Parcelable
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.ServerTimestamp
import kotlinx.android.parcel.Parcelize



@Parcelize
data class Item(var name: String = "", var quantity: Int = 0, var price: Float = 0F) : Parcelable {
    @get:Exclude
    var id = ""
    @ServerTimestamp
    var lastTouched: Timestamp? = null


    companion object {

        fun fromSnapshot(snapshot: DocumentSnapshot): Item {
            val item = snapshot.toObject(Item::class.java)!!
            item.id = snapshot.id
            return item
        }
    }

}
