package edu.rose.snack.snackplus.customer.bootstrap

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import edu.rose.snack.snackplus.R
import edu.rose.snack.snackplus.customer.checkout.CheckoutFragment
import edu.rose.snack.snackplus.customer.item_select.ItemSelectListFragment
import edu.rose.snack.snackplus.customer.login.LoginActivity
import edu.rose.snack.snackplus.models.Item

class MainActivity : AppCompatActivity(), ItemSelectListFragment.OnCheckoutListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)

        val ft = supportFragmentManager.beginTransaction()
        ft.add(R.id.frame_main, ItemSelectListFragment())
        ft.commit()
    }

    override fun onAttachFragment(fragment: Fragment?) {
        if (fragment is ItemSelectListFragment) {
            fragment.setOnCheckoutListener(this)
        }
    }

    override fun onCheckout(selectedItems: Map<String, Int>, total: Float) {
        val fragment = CheckoutFragment()
        val bundle = Bundle()
        bundle.putStringArray(CheckoutFragment.KEYS,selectedItems.keys.toTypedArray())
        bundle.putIntArray(CheckoutFragment.VALUES,selectedItems.values.toIntArray())
        bundle.putFloat(CheckoutFragment.TOTAL, total)
        fragment.arguments = bundle
        val ft = supportFragmentManager.beginTransaction()
        ft.replace(R.id.frame_main, fragment)
        ft.addToBackStack(ItemSelectListFragment.TAG)
        ft.commit()
    }

}
